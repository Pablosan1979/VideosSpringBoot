DELETE FROM `vollmed_api_test`.`pacientes`;

INSERT INTO `vollmed_api_test`.`pacientes` (`id`, `nombre`, `email`, `documento`, `calle`, `distrito`, `complemento`, `numero`, `ciudad`, `telefono`, `activo`)
VALUES ('1', 'amanda', 'xxx@mail.com', '1111111', 'ran', 'ran', '900', '900', 'ran', '12334567', '1');

