package med.voll.api.direccion;

public record DatosDireccion(String calle, String distrito, String ciudad, String numero, String complemento) {
}
